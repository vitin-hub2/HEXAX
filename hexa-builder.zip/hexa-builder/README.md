# HEXA Builder ⚡

> AI-powered web app builder. Describe any app, HEXA generates production-grade HTML — fully functional, visually stunning.

Built with Next.js 14, React 18, and the Anthropic Claude API.

---

## 🚀 Deploy to Vercel (1 minute)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

1. Push this repo to GitHub
2. Import it on [vercel.com/new](https://vercel.com/new)
3. Add your environment variable in the Vercel dashboard:
   - `ANTHROPIC_API_KEY` → your key from [console.anthropic.com](https://console.anthropic.com)
4. Click **Deploy** ✅

---

## 🛠 Local Development

### 1. Install dependencies

```bash
npm install
```

### 2. Set up your API key

```bash
cp .env.local.example .env.local
# Then edit .env.local and paste your Anthropic API key
```

### 3. Run the dev server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 📁 Project Structure

```
hexa-builder/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   └── chat/
│   │   │       └── route.js      # Server-side Anthropic proxy
│   │   ├── globals.css
│   │   ├── layout.js             # HTML shell + Google Fonts
│   │   └── page.js               # Entry point
│   └── components/
│       └── HexaBuilder.jsx       # Main app (all UI + logic)
├── .env.local.example
├── .gitignore
├── next.config.js
└── package.json
```

---

## 🔐 Security

Your `ANTHROPIC_API_KEY` is **never exposed to the browser**. All requests go through the `/api/chat` edge route which injects the key server-side.

---

## ⚙️ Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | ✅ | Your Anthropic API key |

---

## 📄 License

MIT
