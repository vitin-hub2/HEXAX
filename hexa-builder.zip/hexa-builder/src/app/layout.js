import "./globals.css";

export const metadata = {
  title: "HEXA Builder — Build anything complex",
  description:
    "Describe any app, dashboard, game, or product. HEXA generates production-grade HTML — fully functional, visually stunning.",
  openGraph: {
    title: "HEXA Builder",
    description: "AI-powered web app builder. Describe it, HEXA builds it.",
    type: "website",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=DM+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
