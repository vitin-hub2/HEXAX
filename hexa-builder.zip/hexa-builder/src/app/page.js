"use client";

import App from "../components/HexaBuilder";

export default function Page() {
  return <App />;
}
